condition(right,right,right,right,_):-
write('came'),nl,
write('Final procedure in reverse order:'),nl.

condition(Man,Wolf,Goat,_,_):-
Wolf=Goat,not(Goat=Man),write('the Goat ate'),nl,!,fail.
condition(Man,_,Goat,Cabbage,_):-
Cabbage=Goat,not(Goat=Man),write('Cabbage ate'),nl,!,fail.

condition(right,Wolf,Goat,Cabbage,Last):-
not(Last=none),write('Went empty on the left'),nl,
condition(left,Wolf,Goat,Cabbage,none),write('Went empty on the left'),nl.

condition(Together,Together,Goat,Cabbage,Last):-
not(Last=wolf),opposite(Together,Other),
write('Drove the wolf'),write(Other),nl,
condition(Other,Other,Goat,Cabbage,wolf),
write('Drove the wolf '),write(Other),nl.

condition(Together,Wolf,Together,Cabbage,Last):-
not(Last=goat),opposite(Together,Other),
write('Drove the goat '),write(Other),nl,
condition(Other, Wolf, Other,Cabbage,goat),
write('Drove the goat '),write(Other),nl.

condition(Together,Wolf,Goat,Together,Last):-
not(Last=cabbage),opposite(Together,Other),
write('was Taken cabbage '),write(Other),nl,
condition(Other,Wolf,Goat,Other,cabbage),
write('was Taken cabbage '),write(Other),nl.

condition(left,Wolf,Goat,Cabbage,Last):-
not(Last=none),
write('Went empty on the right'),nl,
condition(right,Wolf,Goat,Cabbage,none),
write('Went empty on the right'),nl.

front(right,left).
front(left,right).

goal: -state(left, left, left, left, none).
