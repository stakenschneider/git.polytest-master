// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;
// [define_apint] ---------->



   #define AUTOTB_TVIN_in_r  "../tv/cdatafile/c.lab1_2.autotvin_in_r.dat"
   #define AUTOTB_TVIN_a  "../tv/cdatafile/c.lab1_2.autotvin_a.dat"
   #define AUTOTB_TVIN_b  "../tv/cdatafile/c.lab1_2.autotvin_b.dat"
   #define AUTOTB_TVIN_c  "../tv/cdatafile/c.lab1_2.autotvin_c.dat"
   #define AUTOTB_TVOUT_out_r  "../tv/cdatafile/c.lab1_2.autotvout_out_r.dat"
   #define AUTOTB_TVIN_out_r  "../tv/cdatafile/c.lab1_2.autotvin_out_r.dat"
   #define INTER_TCL  "../tv/cdatafile/ref.tcl"

   #define AUTOTB_TVOUT_PC_out_r  "../tv/rtldatafile/rtl.lab1_2.autotvout_out_r.dat"

class AESL_TRANSACTION {
    public:
        AESL_TRANSACTION(const char* name) {
            mName = (char *)malloc((strlen(name)+1)*sizeof(char));            strcpy(mName,name);
        }
        ~AESL_TRANSACTION() {
            free(mName);        }
    public:
        FILE* mFile;
        char* mName;
};

class INTER_TCL_FILE {
    public:
//functions
        INTER_TCL_FILE(const char* name) {
            mName = name;
            in_r_depth = 0;
            a_depth = 0;
            b_depth = 0;
            c_depth = 0;
            out_r_depth = 0;
            trans_num =0;
        }
        ~INTER_TCL_FILE() {
            mFile.open(mName);
            if (!mFile.good() ) {
                cout<<"Failed to open file ref.tcl."<<endl;
                exit (1);
            }
            string total_list = get_depth_list();
            mFile<<"set depth_list {\n";
            mFile<<total_list; 
            mFile<<"}\n";
            mFile<<"set trans_num "<<trans_num<<endl;
            mFile.close();
        }
        string get_depth_list () {
            stringstream total_list;
            total_list<<"   {in_r "<< in_r_depth << "}\n";
            total_list<<"   {a "<< a_depth << "}\n";
            total_list<<"   {b "<< b_depth << "}\n";
            total_list<<"   {c "<< c_depth << "}\n";
            total_list<<"   {out_r "<< out_r_depth << "}\n";
            return total_list.str();
        }
        void set_num (int num , int* class_num) {
            (*class_num) = (*class_num) > num ? (*class_num) : num;
        }
    public:
//variables
        int in_r_depth;
        int a_depth;
        int b_depth;
        int c_depth;
        int out_r_depth;
        int trans_num;
    private:
        ofstream mFile;
        const char* mName;
};

class AESL_TRANSACTION_PC {
    public:
        AESL_TRANSACTION_PC(const char* name) {
            mName = (char *)malloc((strlen(name)+1)*sizeof(char));            strcpy(mName,name);
        }
        ~AESL_TRANSACTION_PC() {
            free(mName);        }
    public:
        fstream file_token;
        char * mName;
};

extern "C" void lab1_2 (
int in[3],
char a,
char b,
char c,
int out[3]);
extern "C" void AESL_WRAP_lab1_2 (
int in[3],
char a,
char b,
char c,
int out[3]) {

    fstream wrapc_switch_file_token;

    wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");

    fstream wrapc_tv_switch_file_token;

    wrapc_tv_switch_file_token.open(".hls_cosim_wrapc_tv_switch.log");

    int AESL_i;

    if (wrapc_switch_file_token.good()) {

        static unsigned AESL_transaction_pc;

        string AESL_token;

        string AESL_num;

            FILE * communication_file;

            char get_com_str_set[4];

            char get_com_str[19];

            int get_com_int;

            do {

                do {

                    communication_file = fopen("com_wrapc_pc.tcl","r");

                } while (communication_file == NULL);

                fscanf(communication_file, "%s %s %d", get_com_str_set, get_com_str, &get_com_int);

                fclose(communication_file);

            } while (strcmp(get_com_str, "trans_num_wrapc_pc") != 0 || get_com_int < AESL_transaction_pc);

        static AESL_FILE_HANDLER aesl_fh;

        char str[100];

        char transaction_num_char[40];

        sprintf(transaction_num_char, "_%0d", AESL_transaction_pc);

        strcpy(str,AUTOTB_TVOUT_PC_out_r);

        strcat(str,transaction_num_char);

        AESL_TRANSACTION_PC tvout_pc_out_r(str);

        tvout_pc_out_r.file_token.open(tvout_pc_out_r.mName);

        if (!tvout_pc_out_r.file_token.good()) {

            cout<<"Failed to open tv file ."<<tvout_pc_out_r.mName<<endl;

            exit (1);

        }

        tvout_pc_out_r.file_token >> AESL_token;//[[transaction]]

        if ( AESL_token != "[[transaction]]") {

           cout<<"Illegal file tvout_out_r format !"<<endl;

           exit(1);

        }

        tvout_pc_out_r.file_token >> AESL_num;//transaction number

        if (atoi(AESL_num.c_str()) == AESL_transaction_pc ) {

            tvout_pc_out_r.file_token >> AESL_token;//data

            sc_bv<32> *out_r_pc_buffer = new sc_bv<32>[3];

            int i = 0;

            while (AESL_token != "[[/transaction]]") {

                bool no_x = false;

                bool err = false;

                while (!no_x) {

                size_t x_found = AESL_token.find('X');

                if (x_found != string::npos) {

                    if (!err) {

                        cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'out_r', possible cause: There are uninitialized variables in the C design." << endl; 

                        err = true;

                    }

                    AESL_token.replace(x_found, 1, "0");

                } else {

                    no_x = true;

                }

                }

                no_x = false;

                while (!no_x) {

                size_t x_found = AESL_token.find('x', 2);

                if (x_found != string::npos) {

                    if (!err) {

                        cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'out_r', possible cause: There are uninitialized variables in the C design." << endl; 

                        err = true;

                    }

                    AESL_token.replace(x_found, 1, "0");

                } else {

                    no_x = true;

                }

                }

                if (AESL_token != "") {

                    out_r_pc_buffer[i] = AESL_token.c_str();

                    i++;

                }

                tvout_pc_out_r.file_token >> AESL_token;//data or [[/transaction]]

                if (AESL_token == "[[[/runtime]]]" || tvout_pc_out_r.file_token.eof()) {

                   cout<<"Illegal file tvout_out_r format !"<<endl;

                   exit(1);

                }

            }

            tvout_pc_out_r.file_token.close();

            strcpy(str,AUTOTB_TVOUT_PC_out_r);

            strcat(str,transaction_num_char);

            remove(str);

            if (i > 0) {

                sc_lv<32>* out_lv0_0_2_1 = new sc_lv<32>[3];

                AESL_i = 0;

                for (int i_0 = 0; i_0 <= 2; i_0 += 1)

                {

                if(&(out[0]) != NULL)

                {

                out_lv0_0_2_1[0 + AESL_i].range(31, 0) = sc_bv<32>(out_r_pc_buffer[0 + AESL_i].range(31, 0));

                }

                AESL_i++;

                }

                {//bitslice

                {//celement

                AESL_i = 0; //subscript for rtl array

                for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

                    if(&(out[0]) != 0) {

                       out[i_0] = (out_lv0_0_2_1[0 + AESL_i]).to_uint64();

                    }

                    AESL_i++;

                }

                }//celement

                }//bitslice

                }

            delete [] out_r_pc_buffer;

        }

        AESL_transaction_pc ++ ;

    } else if (wrapc_tv_switch_file_token.good()){

        static unsigned AESL_transaction;

        char transaction_num_char[40];

        sprintf(transaction_num_char, "_%0d", AESL_transaction);

        char file_name_char[100];

        strcpy(file_name_char, AUTOTB_TVIN_in_r);

        strcat(file_name_char, transaction_num_char);

        AESL_TRANSACTION tvin_in_r(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_a);

        strcat(file_name_char, transaction_num_char);

        AESL_TRANSACTION tvin_a(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_b);

        strcat(file_name_char, transaction_num_char);

        AESL_TRANSACTION tvin_b(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_c);

        strcat(file_name_char, transaction_num_char);

        AESL_TRANSACTION tvin_c(file_name_char);

        strcpy(file_name_char, AUTOTB_TVOUT_out_r);

        strcat(file_name_char, transaction_num_char);

        AESL_TRANSACTION tvout_out_r(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_out_r);

        strcat(file_name_char, transaction_num_char);

        AESL_TRANSACTION tvin_out_r(file_name_char);

        int leading_zero;

        tvin_in_r.mFile = fopen(tvin_in_r.mName, "w");

        if (tvin_in_r.mFile == NULL) {

            cout<<"Failed to open tv file ."<<tvin_in_r.mName<<endl;

            exit (1);

        }

        fprintf(tvin_in_r.mFile, "[[transaction]] %d\n", AESL_transaction);

        sc_bv<32> *in_r_tvin_wrapc_buffer = new sc_bv<32>[3];

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

        sc_lv<32> in_tmp_mem; 

            if(&(in[0]) != 0) {

            in_tmp_mem = in[i_0];

               in_r_tvin_wrapc_buffer[0 + AESL_i].range(31, 0) = in_tmp_mem.range(31, 0 ) ;

            }

            AESL_i++;

        }

        }//celement

        }//bitslice

        for (int i = 0; i < 3 ; i++) {

            fprintf(tvin_in_r.mFile, "%s\n", (in_r_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());

        }

        fprintf(tvin_in_r.mFile, "[[/transaction]] \n");

        fclose(tvin_in_r.mFile);

        delete [] in_r_tvin_wrapc_buffer;

        tvin_a.mFile = fopen(tvin_a.mName, "w");

        if (tvin_a.mFile == NULL) {

            cout<<"Failed to open tv file ."<<tvin_a.mName<<endl;

            exit (1);

        }

        fprintf(tvin_a.mFile, "[[transaction]] %d\n", AESL_transaction);

        sc_bv<8> a_tvin_wrapc_buffer;

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        sc_lv<8> a_tmp_mem; 

        if(&(a) != 0) {

        a_tmp_mem = a;

           a_tvin_wrapc_buffer.range(7, 0) = a_tmp_mem.range(7, 0 ) ;

        }

        AESL_i++;

        }//celement

        }//bitslice

        for (int i = 0; i < 1 ; i++) {

            fprintf(tvin_a.mFile, "%s\n", (a_tvin_wrapc_buffer).to_string(SC_HEX).c_str());

        }

        fprintf(tvin_a.mFile, "[[/transaction]] \n");

        fclose(tvin_a.mFile);

        tvin_b.mFile = fopen(tvin_b.mName, "w");

        if (tvin_b.mFile == NULL) {

            cout<<"Failed to open tv file ."<<tvin_b.mName<<endl;

            exit (1);

        }

        fprintf(tvin_b.mFile, "[[transaction]] %d\n", AESL_transaction);

        sc_bv<8> b_tvin_wrapc_buffer;

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        sc_lv<8> b_tmp_mem; 

        if(&(b) != 0) {

        b_tmp_mem = b;

           b_tvin_wrapc_buffer.range(7, 0) = b_tmp_mem.range(7, 0 ) ;

        }

        AESL_i++;

        }//celement

        }//bitslice

        for (int i = 0; i < 1 ; i++) {

            fprintf(tvin_b.mFile, "%s\n", (b_tvin_wrapc_buffer).to_string(SC_HEX).c_str());

        }

        fprintf(tvin_b.mFile, "[[/transaction]] \n");

        fclose(tvin_b.mFile);

        tvin_c.mFile = fopen(tvin_c.mName, "w");

        if (tvin_c.mFile == NULL) {

            cout<<"Failed to open tv file ."<<tvin_c.mName<<endl;

            exit (1);

        }

        fprintf(tvin_c.mFile, "[[transaction]] %d\n", AESL_transaction);

        sc_bv<8> c_tvin_wrapc_buffer;

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        sc_lv<8> c_tmp_mem; 

        if(&(c) != 0) {

        c_tmp_mem = c;

           c_tvin_wrapc_buffer.range(7, 0) = c_tmp_mem.range(7, 0 ) ;

        }

        AESL_i++;

        }//celement

        }//bitslice

        for (int i = 0; i < 1 ; i++) {

            fprintf(tvin_c.mFile, "%s\n", (c_tvin_wrapc_buffer).to_string(SC_HEX).c_str());

        }

        fprintf(tvin_c.mFile, "[[/transaction]] \n");

        fclose(tvin_c.mFile);

        tvin_out_r.mFile = fopen(tvin_out_r.mName, "w");

        if (tvin_out_r.mFile == NULL) {

            cout<<"Failed to open tv file ."<<tvin_out_r.mName<<endl;

            exit (1);

        }

        fprintf(tvin_out_r.mFile, "[[transaction]] %d\n", AESL_transaction);

        sc_bv<32> *out_r_tvin_wrapc_buffer = new sc_bv<32>[3];

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

        sc_lv<32> out_tmp_mem; 

            if(&(out[0]) != 0) {

            out_tmp_mem = out[i_0];

               out_r_tvin_wrapc_buffer[0 + AESL_i].range(31, 0) = out_tmp_mem.range(31, 0 ) ;

            }

            AESL_i++;

        }

        }//celement

        }//bitslice

        for (int i = 0; i < 3 ; i++) {

            fprintf(tvin_out_r.mFile, "%s\n", (out_r_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());

        }

        fprintf(tvin_out_r.mFile, "[[/transaction]] \n");

        fclose(tvin_out_r.mFile);

        delete [] out_r_tvin_wrapc_buffer;

        lab1_2(in,a,b,c,out);

        tvout_out_r.mFile = fopen(tvout_out_r.mName, "w");

        if (tvout_out_r.mFile == NULL) {

            cout<<"Failed to open tv file ."<<tvout_out_r.mName<<endl;

            exit (1);

        }

        fprintf(tvout_out_r.mFile, "[[transaction]] %d\n", AESL_transaction);

        sc_bv<32> *out_r_tvout_wrapc_buffer = new sc_bv<32>[3];

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

        sc_lv<32> out_tmp_mem; 

            if(&(out[0]) != 0) {

            out_tmp_mem = out[i_0];

               out_r_tvout_wrapc_buffer[0 + AESL_i].range(31, 0) = out_tmp_mem.range(31, 0 ) ;

            }

            AESL_i++;

        }

        }//celement

        }//bitslice

        for (int i = 0; i < 3 ; i++) {

            fprintf(tvout_out_r.mFile, "%s\n", (out_r_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());

        }

        fprintf(tvout_out_r.mFile, "[[/transaction]] \n");

        fclose(tvout_out_r.mFile);

        delete [] out_r_tvout_wrapc_buffer;
        FILE* communication_file;
        do {
            communication_file = fopen("com_wrapc.tcl", "w");
        } while (communication_file == NULL);
        fprintf(communication_file, "set trans_num_wrapc %d \n\n", AESL_transaction);
        fclose(communication_file);
    if(AESL_transaction > 0) {
        FILE * communication_file;
        char get_com_str_set[4];
        char get_com_str[14];
        int get_com_int;
        do {
            do {
                communication_file = fopen("com_rtl_ready.tcl","r");
            } while (communication_file == NULL);
            fscanf(communication_file, "%s %s %d", get_com_str_set, get_com_str, &get_com_int);
            fclose(communication_file);
        } while (strcmp(get_com_str, "trans_num_rtl") != 0 || get_com_int < AESL_transaction);
    }

        if(AESL_transaction > 0) {

        sprintf(transaction_num_char, "_%0d", AESL_transaction - 1);

        strcpy(file_name_char, AUTOTB_TVIN_in_r);

        strcat(file_name_char, transaction_num_char);

        remove(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_a);

        strcat(file_name_char, transaction_num_char);

        remove(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_b);

        strcat(file_name_char, transaction_num_char);

        remove(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_c);

        strcat(file_name_char, transaction_num_char);

        remove(file_name_char);

        strcpy(file_name_char, AUTOTB_TVOUT_out_r);

        strcat(file_name_char, transaction_num_char);

        remove(file_name_char);

        strcpy(file_name_char, AUTOTB_TVIN_out_r);

        strcat(file_name_char, transaction_num_char);

        remove(file_name_char);
}

        AESL_transaction++;

    } else {

        static unsigned AESL_transaction;

        static AESL_FILE_HANDLER aesl_fh;

        static INTER_TCL_FILE tcl_file(INTER_TCL);


        int leading_zero;

        sc_bv<32> *in_r_tvin_wrapc_buffer = new sc_bv<32>[3];

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

        sc_lv<32> in_tmp_mem; 

            if(&(in[0]) != 0) {

            in_tmp_mem = in[i_0];

               in_r_tvin_wrapc_buffer[0 + AESL_i].range(31, 0) = in_tmp_mem.range(31, 0 ) ;

            }

            AESL_i++;

        }

        }//celement

        }//bitslice

        tcl_file.set_num(3,&tcl_file.in_r_depth);

        delete [] in_r_tvin_wrapc_buffer;

        sc_bv<8> a_tvin_wrapc_buffer;

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        sc_lv<8> a_tmp_mem; 

        if(&(a) != 0) {

        a_tmp_mem = a;

           a_tvin_wrapc_buffer.range(7, 0) = a_tmp_mem.range(7, 0 ) ;

        }

        AESL_i++;

        }//celement

        }//bitslice

        tcl_file.set_num(1,&tcl_file.a_depth);

        sc_bv<8> b_tvin_wrapc_buffer;

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        sc_lv<8> b_tmp_mem; 

        if(&(b) != 0) {

        b_tmp_mem = b;

           b_tvin_wrapc_buffer.range(7, 0) = b_tmp_mem.range(7, 0 ) ;

        }

        AESL_i++;

        }//celement

        }//bitslice

        tcl_file.set_num(1,&tcl_file.b_depth);

        sc_bv<8> c_tvin_wrapc_buffer;

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        sc_lv<8> c_tmp_mem; 

        if(&(c) != 0) {

        c_tmp_mem = c;

           c_tvin_wrapc_buffer.range(7, 0) = c_tmp_mem.range(7, 0 ) ;

        }

        AESL_i++;

        }//celement

        }//bitslice

        tcl_file.set_num(1,&tcl_file.c_depth);

        sc_bv<32> *out_r_tvin_wrapc_buffer = new sc_bv<32>[3];

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

        sc_lv<32> out_tmp_mem; 

            if(&(out[0]) != 0) {

            out_tmp_mem = out[i_0];

               out_r_tvin_wrapc_buffer[0 + AESL_i].range(31, 0) = out_tmp_mem.range(31, 0 ) ;

            }

            AESL_i++;

        }

        }//celement

        }//bitslice

        tcl_file.set_num(3,&tcl_file.out_r_depth);

        delete [] out_r_tvin_wrapc_buffer;

        lab1_2(in,a,b,c,out);

        sc_bv<32> *out_r_tvout_wrapc_buffer = new sc_bv<32>[3];

        {//bitslice

        {//celement

        AESL_i = 0; //subscript for rtl array

        for (int i_0 = 0; i_0 <= 2 ; i_0+= 1) {

        sc_lv<32> out_tmp_mem; 

            if(&(out[0]) != 0) {

            out_tmp_mem = out[i_0];

               out_r_tvout_wrapc_buffer[0 + AESL_i].range(31, 0) = out_tmp_mem.range(31, 0 ) ;

            }

            AESL_i++;

        }

        }//celement

        }//bitslice

        tcl_file.set_num(3,&tcl_file.out_r_depth);

        delete [] out_r_tvout_wrapc_buffer;

        AESL_transaction++;

        tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);

    }
}

