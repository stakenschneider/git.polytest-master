#include <stdio.h>

void lab1_2_original (int in[3], char a, char b, char c, int out[3]) {
  int x, y;
  for(int i = 0; i < 3; i++) {
    x = in[i]; 
    y = a*x + b + c; 
    out[i] = y;
  }
}

int main()
{
	int inA, inB, inC;
	int x[3];
	int res[3];
	// For adders
	int refOut[3];
	int pass;
	int i, j, t;

  pass = 1;
	inA = 10;
	inB = 20;
	inC = 30;

	// Call the adder for 5 transactions
	for (i=0; i<3; i++)
	{
    for (t=0; t<3; t++)
      x[t] = t + 1;

    for (j=0; j<3; j++)
    {
      lab1_2_original(x, inA, inB, inC, refOut);
      lab1_2(x, inA, inB, inC, res);

      fprintf(stdout, "  %d * [%d, %d, %d] + %d + %d = [%d, %d, %d] \n",
          inA,
          x[0], x[1], x[2],
          inB, inC,
          res[0], res[1], res[2]);

      // Test the output against expected results
      for (t=0; t<3; t++)
        pass = pass && (res[t] == refOut[t]);

      for (t=0; t<3; t++)
        x[t] = x[t] + 1;
		}

		inA=inA+10;
		inB=inB+10;
		inC=inC+10;
	}

	if (pass)
	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}
	else
	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
