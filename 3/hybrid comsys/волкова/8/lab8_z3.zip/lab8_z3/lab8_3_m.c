#include "lab8_3.h"

void foo(int data_in[N], int sel, int data_out[N]) {
	int temp1[N], temp2[N];
	Loop1: for(int i = 0; i < N; i++) {
		if (sel) {
			temp1[i] = data_in[i] * 123;
		} else {
			temp1[i] = data_in[i] * 321;
		}
		Loop2: for(int j = 0; j < N; j++) {
			temp2[j] = data_in[j];
		}
		Loop3: for(int k = 0; k < N; k++) {
			data_out[k] = temp1[k] * temp2[k];
		}
	}
}
