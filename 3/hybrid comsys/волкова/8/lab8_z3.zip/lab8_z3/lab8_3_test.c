#include <stdio.h>
#include "lab8_3.h"

int main() {
	int data_in[N];
	int data_out[N];
	int data_out_expected[N];
	int scale = 2;
	int pass = 1;
	int i, j;

	for (i = 0; i < N; i++) {
		data_in[i] = 211*i % 9;
		int temp1 = data_in[i] * 123;
		int temp2 = data_in[i];
		data_out_expected[i] = temp1 * temp2;
	}

	foo(data_in,scale,data_out);

	for (i = 0; i < N; i++) {
		printf("Expected:[%d], \tActual:[%d]\n",data_out_expected[i],data_out[i] );
		if (data_out_expected[i] != data_out[i] ) {
			pass = 0;
		}
	}
	if (pass)	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}	else	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
