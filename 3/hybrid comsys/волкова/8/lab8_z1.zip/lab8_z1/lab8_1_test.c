#include <stdio.h>
#include "lab8_1.h"


void generate_test_data(int scale, int data_in[N], int data_out1[N], int data_out2[N]) {
	int temp1[N]; 
	for(int i = 0; i < N; i++) {
		data_in[i] = i;
		temp1[i] = i * scale;
	}
	for(int j = 0; j < N; j++) {
		data_out1[j] = temp1[j] * 123;
	}
	for(int k = 0; k < N; k++) {
		data_out2[k] = temp1[k] * 456;
	}
}

int compare_array_eq(int actual[N], int expected[N]){
	for (int i = 0; i < N; ++i)	{
		if (actual[i] != expected[i]) {
			fprintf(stdout, "%d: Expeced %d Actual %d\n", i, expected[i], actual[i]);		
			return 0;
		}
	}
	return 1;
}

int main() {
	int pass = 1;
	int scale;
	int data_in[N];
	int data_out1[N], data_out2[N];
	int expected_out1[N], expected_out2[N];


	for (int i = 1; i < 4; ++i)	{
		scale = i;
		generate_test_data(scale, data_in, expected_out1, expected_out2);


		foo(data_in, scale, data_out1, data_out2);

		if(!compare_array_eq(data_out1, expected_out1) || !compare_array_eq(data_out2, expected_out2)){
			pass = 0;
		}

	}

	if (pass)	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}	else	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
