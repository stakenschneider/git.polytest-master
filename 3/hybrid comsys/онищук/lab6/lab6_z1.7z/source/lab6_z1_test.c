#include <stdio.h>
#define N 5

int main() {
  int d[N];
  int i;
  
  for (i = 0; i < N; i++) {
    d[i] = i + 5;
  }

  foo(d);
  
  // check results
  int res[N] = { 6, 13, 21, 30, 9 };
  int pass = 1;

  fprintf(stdout, "Expected     Actual\n");
  fprintf(stdout, "--------     ------\n");
  for (i = 0; i < 5; i++) {
    fprintf(stdout, "res[%d]:%2d == d[%d]:%2d\n", i, res[i], i, d[i]);
    if (res[i] != d[i])
      pass = 0;
  }

	if (pass)
	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}
	else
	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
