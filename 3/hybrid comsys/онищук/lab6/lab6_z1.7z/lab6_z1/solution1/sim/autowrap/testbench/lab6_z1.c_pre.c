# 1 "D:/SPbPU/HLS/lab6_z1/source/lab6_z1.c"
# 1 "D:/SPbPU/HLS/lab6_z1/source/lab6_z1.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "D:/SPbPU/HLS/lab6_z1/source/lab6_z1.c" 2
# 1 "D:/SPbPU/HLS/lab6_z1/source/bus.h" 1
# 2 "D:/SPbPU/HLS/lab6_z1/source/lab6_z1.c" 2

void foo(int d[5]) {
  static int acc = 0;
  int i;

  for (i = 0; i < 4; i++) {
    acc += *(d + i + 1);
    *(d + i) = acc;
  }
}
