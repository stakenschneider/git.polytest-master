// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern data_t AESL_WRAP_struct_port (
data_t i_val,
data_t* i_pt,
data_t* o_pt);
