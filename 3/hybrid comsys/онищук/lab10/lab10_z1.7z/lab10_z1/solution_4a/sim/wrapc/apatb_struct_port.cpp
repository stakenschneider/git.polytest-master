// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;


// [dump_struct_tree [build_nameSpaceTree] dumpedStructList] ---------->
                      typedef struct {
                          unsigned short A;
                          unsigned char B[4];
                         } data_t;



// [dump_enumeration [get_enumeration_list]] ---------->


// wrapc file define: "agg_result_A"
#define AUTOTB_TVOUT_agg_result_A  "../tv/cdatafile/c.struct_port.autotvout_agg_result_A.dat"
// wrapc file define: "agg_result_B"
#define AUTOTB_TVOUT_agg_result_B  "../tv/cdatafile/c.struct_port.autotvout_agg_result_B.dat"
#define AUTOTB_TVIN_agg_result_B  "../tv/cdatafile/c.struct_port.autotvin_agg_result_B.dat"
// wrapc file define: "i_val"
#define AUTOTB_TVIN_i_val  "../tv/cdatafile/c.struct_port.autotvin_i_val.dat"
// wrapc file define: "i_pt"
#define AUTOTB_TVIN_i_pt  "../tv/cdatafile/c.struct_port.autotvin_i_pt.dat"
// wrapc file define: "o_pt"
#define AUTOTB_TVOUT_o_pt  "../tv/cdatafile/c.struct_port.autotvout_o_pt.dat"

#define INTER_TCL  "../tv/cdatafile/ref.tcl"

// tvout file define: "agg_result_A"
#define AUTOTB_TVOUT_PC_agg_result_A  "../tv/rtldatafile/rtl.struct_port.autotvout_agg_result_A.dat"
// tvout file define: "agg_result_B"
#define AUTOTB_TVOUT_PC_agg_result_B  "../tv/rtldatafile/rtl.struct_port.autotvout_agg_result_B.dat"
// tvout file define: "o_pt"
#define AUTOTB_TVOUT_PC_o_pt  "../tv/rtldatafile/rtl.struct_port.autotvout_o_pt.dat"

class INTER_TCL_FILE {
	public:
		INTER_TCL_FILE(const char* name) {
			mName = name;
			agg_result_A_depth = 0;
			agg_result_B_depth = 0;
			i_val_depth = 0;
			i_pt_depth = 0;
			o_pt_depth = 0;
			trans_num =0;
		}

		~INTER_TCL_FILE() {
			mFile.open(mName);
			if (!mFile.good()) {
				cout << "Failed to open file ref.tcl" << endl;
				exit (1);
			}
			string total_list = get_depth_list();
			mFile << "set depth_list {\n";
			mFile << total_list;
			mFile << "}\n";
			mFile << "set trans_num "<<trans_num<<endl;
			mFile.close();
		}

		string get_depth_list () {
			stringstream total_list;
			total_list << "{agg_result_A " << agg_result_A_depth << "}\n";
			total_list << "{agg_result_B " << agg_result_B_depth << "}\n";
			total_list << "{i_val " << i_val_depth << "}\n";
			total_list << "{i_pt " << i_pt_depth << "}\n";
			total_list << "{o_pt " << o_pt_depth << "}\n";
			return total_list.str();
		}

		void set_num (int num , int* class_num) {
			(*class_num) = (*class_num) > num ? (*class_num) : num;
		}
	public:
		int agg_result_A_depth;
		int agg_result_B_depth;
		int i_val_depth;
		int i_pt_depth;
		int o_pt_depth;
		int trans_num;

	private:
		ofstream mFile;
		const char* mName;
};

extern "C" data_t struct_port (
data_t i_val,
data_t* i_pt,
data_t* o_pt);

extern "C" data_t AESL_WRAP_struct_port (
data_t i_val,
data_t* i_pt,
data_t* o_pt)
{
	refine_signal_handler();
	fstream wrapc_switch_file_token;
	wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
	int AESL_i;
	if (wrapc_switch_file_token.good())
	{
		CodeState = ENTER_WRAPC_PC;
		static unsigned AESL_transaction_pc = 0;
		string AESL_token;
		string AESL_num;
		static AESL_FILE_HANDLER aesl_fh;

		data_t AESL_return;

		// output port post check: "agg_result_A"
		aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_A, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_A, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_A, AESL_token); // data

			sc_bv<16> *agg_result_A_pc_buffer = new sc_bv<16>[1];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'agg_result_A', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'agg_result_A', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					agg_result_A_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_A, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_agg_result_A))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: agg_result_A
				{
					// bitslice(15, 0)
					// {
						// celement: agg.result.A(15, 0)
						// {
							sc_lv<16>* agg_result_A_lv0_0_0_1 = new sc_lv<16>[1];
						// }
					// }

					// bitslice(15, 0)
					{
						int hls_map_index = 0;
						// celement: agg.result.A(15, 0)
						{
							// carray: (0) => (0) @ (1)
							for (int i_0 = 0; i_0 <= 0; i_0 += 1)
							{
								if (&(AESL_return.A) != NULL) // check the null address if the c port is array or others
								{
									agg_result_A_lv0_0_0_1[hls_map_index].range(15, 0) = sc_bv<16>(agg_result_A_pc_buffer[hls_map_index].range(15, 0));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(15, 0)
					{
						int hls_map_index = 0;
						// celement: agg.result.A(15, 0)
						{
							// carray: (0) => (0) @ (1)
							for (int i_0 = 0; i_0 <= 0; i_0 += 1)
							{
								// sub                    : i_0
								// ori_name               : AESL_return.A
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : AESL_return.A
								// output_left_conversion : AESL_return.A
								// output_type_conversion : (agg_result_A_lv0_0_0_1[hls_map_index]).to_uint64()
								if (&(AESL_return.A) != NULL) // check the null address if the c port is array or others
								{
									AESL_return.A = (agg_result_A_lv0_0_0_1[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] agg_result_A_pc_buffer;
		}

		// output port post check: "agg_result_B"
		aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_B, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_B, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_B, AESL_token); // data

			sc_bv<8> *agg_result_B_pc_buffer = new sc_bv<8>[4];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'agg_result_B', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'agg_result_B', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					agg_result_B_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_agg_result_B, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_agg_result_B))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: agg_result_B
				{
					// bitslice(7, 0)
					// {
						// celement: agg.result.B(7, 0)
						// {
							sc_lv<8>* agg_result_B_lv0_0_3_1 = new sc_lv<8>[4];
						// }
					// }

					// bitslice(7, 0)
					{
						int hls_map_index = 0;
						// celement: agg.result.B(7, 0)
						{
							// carray: (0) => (3) @ (1)
							for (int i_0 = 0; i_0 <= 3; i_0 += 1)
							{
								if (&(AESL_return.B[0]) != NULL) // check the null address if the c port is array or others
								{
									agg_result_B_lv0_0_3_1[hls_map_index].range(7, 0) = sc_bv<8>(agg_result_B_pc_buffer[hls_map_index].range(7, 0));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(7, 0)
					{
						int hls_map_index = 0;
						// celement: agg.result.B(7, 0)
						{
							// carray: (0) => (3) @ (1)
							for (int i_0 = 0; i_0 <= 3; i_0 += 1)
							{
								// sub                    : i_0
								// ori_name               : AESL_return.B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : AESL_return.B[0]
								// output_left_conversion : AESL_return.B[i_0]
								// output_type_conversion : (agg_result_B_lv0_0_3_1[hls_map_index]).to_uint64()
								if (&(AESL_return.B[0]) != NULL) // check the null address if the c port is array or others
								{
									AESL_return.B[i_0] = (agg_result_B_lv0_0_3_1[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] agg_result_B_pc_buffer;
		}

		// output port post check: "o_pt"
		aesl_fh.read(AUTOTB_TVOUT_PC_o_pt, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_o_pt, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_o_pt, AESL_token); // data

			sc_bv<48> *o_pt_pc_buffer = new sc_bv<48>[1];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'o_pt', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'o_pt', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					o_pt_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_o_pt, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_o_pt))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: o_pt
				{
					// bitslice(15, 0)
					// {
						// celement: o_pt.A(15, 0)
						// {
							sc_lv<16>* o_pt_A_lv0_0_0_1 = new sc_lv<16>[1];
						// }
					// }
					// bitslice(23, 16)
					// {
						// celement: o_pt.B(7, 0)
						// {
							sc_lv<8>* o_pt_B_lv0_0_0_2 = new sc_lv<8>[1];
						// }
					// }
					// bitslice(31, 24)
					// {
						// celement: o_pt.B(7, 0)
						// {
							sc_lv<8>* o_pt_B_lv0_1_1_2 = new sc_lv<8>[1];
						// }
					// }
					// bitslice(39, 32)
					// {
						// celement: o_pt.B(7, 0)
						// {
							sc_lv<8>* o_pt_B_lv0_2_2_2 = new sc_lv<8>[1];
						// }
					// }
					// bitslice(47, 40)
					// {
						// celement: o_pt.B(7, 0)
						// {
							sc_lv<8>* o_pt_B_lv0_3_3_2 = new sc_lv<8>[1];
						// }
					// }

					// bitslice(15, 0)
					{
						int hls_map_index = 0;
						// celement: o_pt.A(15, 0)
						{
							// carray: (0) => (0) @ (1)
							for (int i_0 = 0; i_0 <= 0; i_0 += 1)
							{
								if (&(o_pt->A) != NULL) // check the null address if the c port is array or others
								{
									o_pt_A_lv0_0_0_1[hls_map_index].range(15, 0) = sc_bv<16>(o_pt_pc_buffer[hls_map_index].range(15, 0));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(23, 16)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (0) => (0) @ (2)
							for (int i_0 = 0; i_0 <= 0; i_0 += 2)
							{
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt_B_lv0_0_0_2[hls_map_index].range(7, 0) = sc_bv<8>(o_pt_pc_buffer[hls_map_index].range(23, 16));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(31, 24)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (1) => (1) @ (2)
							for (int i_0 = 1; i_0 <= 1; i_0 += 2)
							{
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt_B_lv0_1_1_2[hls_map_index].range(7, 0) = sc_bv<8>(o_pt_pc_buffer[hls_map_index].range(31, 24));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(39, 32)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (2) => (2) @ (2)
							for (int i_0 = 2; i_0 <= 2; i_0 += 2)
							{
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt_B_lv0_2_2_2[hls_map_index].range(7, 0) = sc_bv<8>(o_pt_pc_buffer[hls_map_index].range(39, 32));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(47, 40)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (3) => (3) @ (2)
							for (int i_0 = 3; i_0 <= 3; i_0 += 2)
							{
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt_B_lv0_3_3_2[hls_map_index].range(7, 0) = sc_bv<8>(o_pt_pc_buffer[hls_map_index].range(47, 40));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(15, 0)
					{
						int hls_map_index = 0;
						// celement: o_pt.A(15, 0)
						{
							// carray: (0) => (0) @ (1)
							for (int i_0 = 0; i_0 <= 0; i_0 += 1)
							{
								// sub                    : i_0
								// ori_name               : o_pt->A
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : o_pt->A
								// output_left_conversion : o_pt->A
								// output_type_conversion : (o_pt_A_lv0_0_0_1[hls_map_index]).to_uint64()
								if (&(o_pt->A) != NULL) // check the null address if the c port is array or others
								{
									o_pt->A = (o_pt_A_lv0_0_0_1[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(23, 16)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (0) => (0) @ (2)
							for (int i_0 = 0; i_0 <= 0; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : o_pt->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : o_pt->B[0]
								// output_left_conversion : o_pt->B[i_0]
								// output_type_conversion : (o_pt_B_lv0_0_0_2[hls_map_index]).to_uint64()
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt->B[i_0] = (o_pt_B_lv0_0_0_2[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(31, 24)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (1) => (1) @ (2)
							for (int i_0 = 1; i_0 <= 1; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : o_pt->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : o_pt->B[0]
								// output_left_conversion : o_pt->B[i_0]
								// output_type_conversion : (o_pt_B_lv0_1_1_2[hls_map_index]).to_uint64()
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt->B[i_0] = (o_pt_B_lv0_1_1_2[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(39, 32)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (2) => (2) @ (2)
							for (int i_0 = 2; i_0 <= 2; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : o_pt->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : o_pt->B[0]
								// output_left_conversion : o_pt->B[i_0]
								// output_type_conversion : (o_pt_B_lv0_2_2_2[hls_map_index]).to_uint64()
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt->B[i_0] = (o_pt_B_lv0_2_2_2[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(47, 40)
					{
						int hls_map_index = 0;
						// celement: o_pt.B(7, 0)
						{
							// carray: (3) => (3) @ (2)
							for (int i_0 = 3; i_0 <= 3; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : o_pt->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : o_pt->B[0]
								// output_left_conversion : o_pt->B[i_0]
								// output_type_conversion : (o_pt_B_lv0_3_3_2[hls_map_index]).to_uint64()
								if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
								{
									o_pt->B[i_0] = (o_pt_B_lv0_3_3_2[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] o_pt_pc_buffer;
		}

		AESL_transaction_pc++;

		return AESL_return;
	}
	else
	{
		CodeState = ENTER_WRAPC;
		static unsigned AESL_transaction;

		static AESL_FILE_HANDLER aesl_fh;

		// "agg_result_A"
		char* tvout_agg_result_A = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_agg_result_A);

		// "agg_result_B"
		char* tvin_agg_result_B = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_agg_result_B);
		char* tvout_agg_result_B = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_agg_result_B);

		// "i_val"
		char* tvin_i_val = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_i_val);

		// "i_pt"
		char* tvin_i_pt = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_i_pt);

		// "o_pt"
		char* tvout_o_pt = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_o_pt);

		CodeState = DUMP_INPUTS;
		static INTER_TCL_FILE tcl_file(INTER_TCL);
		int leading_zero;

		// [[transaction]]
		sprintf(tvin_i_val, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_i_val, tvin_i_val);

		sc_bv<48>* i_val_tvin_wrapc_buffer = new sc_bv<48>[1];

		// RTL Name: i_val
		{
			// bitslice(15, 0)
			{
				int hls_map_index = 0;
				// celement: i_val.A(15, 0)
				{
					// carray: (0) => (0) @ (0)
					{
						// sub                   : 
						// ori_name              : i_val.A
						// sub_1st_elem          : 
						// ori_name_1st_elem     : i_val.A
						// regulate_c_name       : i_val_A
						// input_type_conversion : i_val.A
						if (&(i_val.A) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<16> i_val_A_tmp_mem;
							i_val_A_tmp_mem = i_val.A;
							i_val_tvin_wrapc_buffer[hls_map_index].range(15, 0) = i_val_A_tmp_mem.range(15, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(23, 16)
			{
				int hls_map_index = 0;
				// celement: i_val.B(7, 0)
				{
					// carray: (0) => (0) @ (2)
					for (int i_0 = 0; i_0 <= 0; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_val.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_val.B[0]
						// regulate_c_name       : i_val_B
						// input_type_conversion : i_val.B[i_0]
						if (&(i_val.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_val_B_tmp_mem;
							i_val_B_tmp_mem = i_val.B[i_0];
							i_val_tvin_wrapc_buffer[hls_map_index].range(23, 16) = i_val_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(31, 24)
			{
				int hls_map_index = 0;
				// celement: i_val.B(7, 0)
				{
					// carray: (1) => (1) @ (2)
					for (int i_0 = 1; i_0 <= 1; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_val.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_val.B[0]
						// regulate_c_name       : i_val_B
						// input_type_conversion : i_val.B[i_0]
						if (&(i_val.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_val_B_tmp_mem;
							i_val_B_tmp_mem = i_val.B[i_0];
							i_val_tvin_wrapc_buffer[hls_map_index].range(31, 24) = i_val_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(39, 32)
			{
				int hls_map_index = 0;
				// celement: i_val.B(7, 0)
				{
					// carray: (2) => (2) @ (2)
					for (int i_0 = 2; i_0 <= 2; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_val.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_val.B[0]
						// regulate_c_name       : i_val_B
						// input_type_conversion : i_val.B[i_0]
						if (&(i_val.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_val_B_tmp_mem;
							i_val_B_tmp_mem = i_val.B[i_0];
							i_val_tvin_wrapc_buffer[hls_map_index].range(39, 32) = i_val_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(47, 40)
			{
				int hls_map_index = 0;
				// celement: i_val.B(7, 0)
				{
					// carray: (3) => (3) @ (2)
					for (int i_0 = 3; i_0 <= 3; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_val.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_val.B[0]
						// regulate_c_name       : i_val_B
						// input_type_conversion : i_val.B[i_0]
						if (&(i_val.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_val_B_tmp_mem;
							i_val_B_tmp_mem = i_val.B[i_0];
							i_val_tvin_wrapc_buffer[hls_map_index].range(47, 40) = i_val_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_i_val, "%s\n", (i_val_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_i_val, tvin_i_val);
		}

		tcl_file.set_num(1, &tcl_file.i_val_depth);
		sprintf(tvin_i_val, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_i_val, tvin_i_val);

		// release memory allocation
		delete [] i_val_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_i_pt, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_i_pt, tvin_i_pt);

		sc_bv<48>* i_pt_tvin_wrapc_buffer = new sc_bv<48>[1];

		// RTL Name: i_pt
		{
			// bitslice(15, 0)
			{
				int hls_map_index = 0;
				// celement: i_pt.A(15, 0)
				{
					// carray: (0) => (0) @ (1)
					for (int i_0 = 0; i_0 <= 0; i_0 += 1)
					{
						// sub                   : i_0
						// ori_name              : i_pt->A
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_pt->A
						// regulate_c_name       : i_pt_A
						// input_type_conversion : i_pt->A
						if (&(i_pt->A) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<16> i_pt_A_tmp_mem;
							i_pt_A_tmp_mem = i_pt->A;
							i_pt_tvin_wrapc_buffer[hls_map_index].range(15, 0) = i_pt_A_tmp_mem.range(15, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(23, 16)
			{
				int hls_map_index = 0;
				// celement: i_pt.B(7, 0)
				{
					// carray: (0) => (0) @ (2)
					for (int i_0 = 0; i_0 <= 0; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_pt->B[0]
						// regulate_c_name       : i_pt_B
						// input_type_conversion : i_pt->B[i_0]
						if (&(i_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_pt_B_tmp_mem;
							i_pt_B_tmp_mem = i_pt->B[i_0];
							i_pt_tvin_wrapc_buffer[hls_map_index].range(23, 16) = i_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(31, 24)
			{
				int hls_map_index = 0;
				// celement: i_pt.B(7, 0)
				{
					// carray: (1) => (1) @ (2)
					for (int i_0 = 1; i_0 <= 1; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_pt->B[0]
						// regulate_c_name       : i_pt_B
						// input_type_conversion : i_pt->B[i_0]
						if (&(i_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_pt_B_tmp_mem;
							i_pt_B_tmp_mem = i_pt->B[i_0];
							i_pt_tvin_wrapc_buffer[hls_map_index].range(31, 24) = i_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(39, 32)
			{
				int hls_map_index = 0;
				// celement: i_pt.B(7, 0)
				{
					// carray: (2) => (2) @ (2)
					for (int i_0 = 2; i_0 <= 2; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_pt->B[0]
						// regulate_c_name       : i_pt_B
						// input_type_conversion : i_pt->B[i_0]
						if (&(i_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_pt_B_tmp_mem;
							i_pt_B_tmp_mem = i_pt->B[i_0];
							i_pt_tvin_wrapc_buffer[hls_map_index].range(39, 32) = i_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(47, 40)
			{
				int hls_map_index = 0;
				// celement: i_pt.B(7, 0)
				{
					// carray: (3) => (3) @ (2)
					for (int i_0 = 3; i_0 <= 3; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : i_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : i_pt->B[0]
						// regulate_c_name       : i_pt_B
						// input_type_conversion : i_pt->B[i_0]
						if (&(i_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> i_pt_B_tmp_mem;
							i_pt_B_tmp_mem = i_pt->B[i_0];
							i_pt_tvin_wrapc_buffer[hls_map_index].range(47, 40) = i_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_i_pt, "%s\n", (i_pt_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_i_pt, tvin_i_pt);
		}

		tcl_file.set_num(1, &tcl_file.i_pt_depth);
		sprintf(tvin_i_pt, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_i_pt, tvin_i_pt);

		// release memory allocation
		delete [] i_pt_tvin_wrapc_buffer;

// [call_c_dut] ---------->

		CodeState = CALL_C_DUT;
		data_t AESL_return = struct_port(i_val, i_pt, o_pt);

		CodeState = DUMP_OUTPUTS;

		// [[transaction]]
		sprintf(tvout_agg_result_A, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_agg_result_A, tvout_agg_result_A);

		sc_bv<16>* agg_result_A_tvout_wrapc_buffer = new sc_bv<16>[1];

		// RTL Name: agg_result_A
		{
			// bitslice(15, 0)
			{
				int hls_map_index = 0;
				// celement: agg.result.A(15, 0)
				{
					// carray: (0) => (0) @ (1)
					for (int i_0 = 0; i_0 <= 0; i_0 += 1)
					{
						// sub                   : i_0
						// ori_name              : AESL_return.A
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : AESL_return.A
						// regulate_c_name       : agg_result_A
						// input_type_conversion : AESL_return.A
						if (&(AESL_return.A) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<16> agg_result_A_tmp_mem;
							agg_result_A_tmp_mem = AESL_return.A;
							agg_result_A_tvout_wrapc_buffer[hls_map_index].range(15, 0) = agg_result_A_tmp_mem.range(15, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvout_agg_result_A, "%s\n", (agg_result_A_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_agg_result_A, tvout_agg_result_A);
		}

		tcl_file.set_num(1, &tcl_file.agg_result_A_depth);
		sprintf(tvout_agg_result_A, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_agg_result_A, tvout_agg_result_A);

		// release memory allocation
		delete [] agg_result_A_tvout_wrapc_buffer;

		// [[transaction]]
		sprintf(tvout_agg_result_B, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_agg_result_B, tvout_agg_result_B);

		sc_bv<8>* agg_result_B_tvout_wrapc_buffer = new sc_bv<8>[4];

		// RTL Name: agg_result_B
		{
			// bitslice(7, 0)
			{
				int hls_map_index = 0;
				// celement: agg.result.B(7, 0)
				{
					// carray: (0) => (3) @ (1)
					for (int i_0 = 0; i_0 <= 3; i_0 += 1)
					{
						// sub                   : i_0
						// ori_name              : AESL_return.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : AESL_return.B[0]
						// regulate_c_name       : agg_result_B
						// input_type_conversion : AESL_return.B[i_0]
						if (&(AESL_return.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> agg_result_B_tmp_mem;
							agg_result_B_tmp_mem = AESL_return.B[i_0];
							agg_result_B_tvout_wrapc_buffer[hls_map_index].range(7, 0) = agg_result_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4; i++)
		{
			sprintf(tvout_agg_result_B, "%s\n", (agg_result_B_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_agg_result_B, tvout_agg_result_B);
		}

		tcl_file.set_num(4, &tcl_file.agg_result_B_depth);
		sprintf(tvout_agg_result_B, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_agg_result_B, tvout_agg_result_B);

		// release memory allocation
		delete [] agg_result_B_tvout_wrapc_buffer;

		// [[transaction]]
		sprintf(tvout_o_pt, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_o_pt, tvout_o_pt);

		sc_bv<48>* o_pt_tvout_wrapc_buffer = new sc_bv<48>[1];

		// RTL Name: o_pt
		{
			// bitslice(15, 0)
			{
				int hls_map_index = 0;
				// celement: o_pt.A(15, 0)
				{
					// carray: (0) => (0) @ (1)
					for (int i_0 = 0; i_0 <= 0; i_0 += 1)
					{
						// sub                   : i_0
						// ori_name              : o_pt->A
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : o_pt->A
						// regulate_c_name       : o_pt_A
						// input_type_conversion : o_pt->A
						if (&(o_pt->A) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<16> o_pt_A_tmp_mem;
							o_pt_A_tmp_mem = o_pt->A;
							o_pt_tvout_wrapc_buffer[hls_map_index].range(15, 0) = o_pt_A_tmp_mem.range(15, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(23, 16)
			{
				int hls_map_index = 0;
				// celement: o_pt.B(7, 0)
				{
					// carray: (0) => (0) @ (2)
					for (int i_0 = 0; i_0 <= 0; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : o_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : o_pt->B[0]
						// regulate_c_name       : o_pt_B
						// input_type_conversion : o_pt->B[i_0]
						if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> o_pt_B_tmp_mem;
							o_pt_B_tmp_mem = o_pt->B[i_0];
							o_pt_tvout_wrapc_buffer[hls_map_index].range(23, 16) = o_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(31, 24)
			{
				int hls_map_index = 0;
				// celement: o_pt.B(7, 0)
				{
					// carray: (1) => (1) @ (2)
					for (int i_0 = 1; i_0 <= 1; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : o_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : o_pt->B[0]
						// regulate_c_name       : o_pt_B
						// input_type_conversion : o_pt->B[i_0]
						if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> o_pt_B_tmp_mem;
							o_pt_B_tmp_mem = o_pt->B[i_0];
							o_pt_tvout_wrapc_buffer[hls_map_index].range(31, 24) = o_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(39, 32)
			{
				int hls_map_index = 0;
				// celement: o_pt.B(7, 0)
				{
					// carray: (2) => (2) @ (2)
					for (int i_0 = 2; i_0 <= 2; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : o_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : o_pt->B[0]
						// regulate_c_name       : o_pt_B
						// input_type_conversion : o_pt->B[i_0]
						if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> o_pt_B_tmp_mem;
							o_pt_B_tmp_mem = o_pt->B[i_0];
							o_pt_tvout_wrapc_buffer[hls_map_index].range(39, 32) = o_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(47, 40)
			{
				int hls_map_index = 0;
				// celement: o_pt.B(7, 0)
				{
					// carray: (3) => (3) @ (2)
					for (int i_0 = 3; i_0 <= 3; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : o_pt->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : o_pt->B[0]
						// regulate_c_name       : o_pt_B
						// input_type_conversion : o_pt->B[i_0]
						if (&(o_pt->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<8> o_pt_B_tmp_mem;
							o_pt_B_tmp_mem = o_pt->B[i_0];
							o_pt_tvout_wrapc_buffer[hls_map_index].range(47, 40) = o_pt_B_tmp_mem.range(7, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvout_o_pt, "%s\n", (o_pt_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_o_pt, tvout_o_pt);
		}

		tcl_file.set_num(1, &tcl_file.o_pt_depth);
		sprintf(tvout_o_pt, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_o_pt, tvout_o_pt);

		// release memory allocation
		delete [] o_pt_tvout_wrapc_buffer;

		CodeState = DELETE_CHAR_BUFFERS;
		// release memory allocation: "agg_result_A"
		delete [] tvout_agg_result_A;
		// release memory allocation: "agg_result_B"
		delete [] tvout_agg_result_B;
		delete [] tvin_agg_result_B;
		// release memory allocation: "i_val"
		delete [] tvin_i_val;
		// release memory allocation: "i_pt"
		delete [] tvin_i_pt;
		// release memory allocation: "o_pt"
		delete [] tvout_o_pt;

		AESL_transaction++;

		tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);

		return AESL_return;
	}
}

