int lab1_1( char a, char b, char c, char d) {
int y;
y = a*b+c+d;
return y;
}
