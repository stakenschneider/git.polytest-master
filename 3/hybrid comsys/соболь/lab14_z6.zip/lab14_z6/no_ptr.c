#include "pointer_multi.h"

dout_t pointer_multi (sel_t sel, din_t pos) {
  if (sel){ 
    return  1 + pos;
  } else {
    return 8 - pos;
  }
} 
