#include "lab9_2_2.h"

void foo_b(short d_in[N], short d_out[N/4 + 3]){
	for (short i=0; i<N/4; i++){
		d_out[i]   = d_in[i]*d_in[i+4];
		d_out[i+1] = d_in[i+8]*d_in[i+12];
		d_out[i+2] = d_in[i]*d_in[i+12];
		d_out[i+3] = d_in[i+4]*d_in[i+8];
	}
}
