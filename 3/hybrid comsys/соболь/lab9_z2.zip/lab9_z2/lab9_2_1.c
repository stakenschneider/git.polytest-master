#include "lab9_2_1.h"

void foo_a(short d_in[N], short d_out[N/4]){
	for (short i=0; i<N/4; i++){
		d_out[i] = d_in[i]*d_in[i+8] + d_in[i+4]*d_in[i+12];
	}
}
