#include <stdio.h>
#include "lab9_2_1.h"


void generate_test_data(short scale, short d_in[N], short d_out[N/4]) {
	short i;
	for (i = 0; i < N; ++i){
		d_in[i] = (i + 1) * scale;
	}

	for (i=0; i<N/4; i++){
		d_out[i] = d_in[i]*d_in[i+8] + d_in[i+4]*d_in[i+12];
	}
}

int compare_array_eq(short actual[N/4], short expected[N/4]){
	for (int i = 0; i < N/4; ++i)	{
		if (actual[i] != expected[i]) {
			fprintf(stdout, "%d: Expeced %d Actual %d\n", i, expected[i], actual[i]);		
			return 0;
		}
	}
	return 1;
}

int main() {
	int pass = 1;
	short d_in[N];
	short d_out[N/4];
	short expected_out[N/4];


	for (int i = 1; i < 4; ++i)	{
		generate_test_data(i, d_in, expected_out);

		foo_a(d_in, d_out);

		if(!compare_array_eq(d_out, expected_out)){
			pass = 0;
		}

	}

	if (pass)	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}	else	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
