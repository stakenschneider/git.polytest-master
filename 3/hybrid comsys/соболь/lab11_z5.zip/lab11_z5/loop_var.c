#include "loop_var.h"

dout_t loop_var(din_t A[N], dsel_t width) {  
  #ifdef ASSERT_WIDTH_64
     assert(width < 64);
  #endif		

  dout_t out_accum=0;
  dsel_t x;
  
  LOOP_X:for (x=0;x<width; x++) {
      out_accum += A[x];
  }

  return out_accum;
}

