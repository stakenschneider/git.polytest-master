#ifndef _LOOP_VAR_H_
#define _LOOP_VAR_H_

#include <stdio.h>
#include "ap_cint.h"
#include "assert.h"
#define N 32

typedef int8 din_t;
typedef int13 dout_t;
typedef uint5 dsel_t;

dout_t loop_var(din_t A[N], dsel_t width);

#endif

