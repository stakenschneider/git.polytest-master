#include <stdio.h>

#define TEST_COUNT 3

int array_equals(int* first, int* second, int size) {
	for (int i = 0; i < size; i++) {
		if (first[i] != second[i]) {
			return 0;
		}
	}
	return 1;
}

void print_array(int* array, int size) {
	for (int i = 0; i < size; i++) {
		fprintf(stdout, "%d ", array[i]);
	}
	fprintf(stdout, "\n");
}

int main() {
	int inA[TEST_COUNT] = { 1, 2, 3 };
	int inB[TEST_COUNT] = { 1, 2, 3 };
	int inC[TEST_COUNT] = { 1, 2, 3 };
	int inX[TEST_COUNT][3] = { { 0, 1, 2 }, { 1, 2, 0 }, { 2, 0, 1 } };
	int refOut[TEST_COUNT][3] = { { 2, 3, 4 }, { 6, 8, 4 }, { 12, 6, 9 } };

	int res[3];
	int pass;
	int i;

	for (i = 0; i < TEST_COUNT; i++) {
		lab1_2(inX[i], inA[i], inB[i], inC[i], res);
		pass = array_equals(res, refOut[i], 3);
		fprintf(stdout, "Test %d: passed %d \n", i, pass);
		fprintf(stdout, "Expected: ");
		print_array(refOut[i], 3);
		fprintf(stdout, "Actual: ");
		print_array(res, 3);
	}

	if (pass == 1) {
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	} else {
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
