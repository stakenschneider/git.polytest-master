#include "lab7_2.h"

#include <stdio.h>

int main()
{
    int in1[N][M], in2[N][M], out[N][M], expected[N][M];
    int i, j;
    int pass = 1;

    for (i = 0; i < N; ++i) {
        for (j = 0; j < M; ++j) {
            in1[i][j] = (i + 1) * (j + 1);
            in2[i][j] = i * j;
            out[i][j] = 0;
            expected[i][j] = (i + 1) * (j + 1) + i * j;
        }
    }

    lab7_2(in1, in2, out);

    for (i = 0; i < N; ++i) {
        for (j = 0; j < M; ++j) {
            fprintf(stdout, "%d,%d: expected %d, actual %d \n", i, j, expected[i][j], out[i][j]);           
            if(expected[i][j] != out[i][j]){
                pass = 0;
            }
        }
    }

    if (pass) {
        fprintf(stdout, "----------Pass!------------\n");
        return 0;
    } else {
        fprintf(stderr, "----------Fail!------------\n");
        return 1;
    }
}
