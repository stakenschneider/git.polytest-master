#include "lab7_2.h"

void lab7_2(int in1[N][M], int in2[N][M], int out[N][M]){
    int i, j;
    L1: for (i = 0; i < N; ++i) {
        L2: for (j = 0; j < M; ++j) {
            out[i][j] = in1[i][j] + in2[i][j];
        }
    }
}

