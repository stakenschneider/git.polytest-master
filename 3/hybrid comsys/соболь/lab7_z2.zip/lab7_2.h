#define N 3
#define M 3

void lab7_2(int in1[N][M], int in2[N][M], int out[N][M]);
