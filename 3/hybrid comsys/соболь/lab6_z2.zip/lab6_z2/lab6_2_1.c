void foo(int *d) {
   static int acc = 0;
   int i;
   acc += d[i];
   d[i] = acc;
}