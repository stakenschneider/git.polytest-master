void foo(int *d) {
   int buf1[4], buf2[4];
   int i;

   memcpy(buf1, d, 4*sizeof(int));

   for (i = 0; i < 4; i++) {
	  buf2[i] = buf1[3 - i];
   }

  memcpy(d, buf2, 4*sizeof(int));	
}