void foo(int *d) {
   static int acc = 0;
   int i;
   for (i = 0; i < 4; i++) {
	   acc += *(d + i);
	   *(d + i) = acc;	
   }
   
}