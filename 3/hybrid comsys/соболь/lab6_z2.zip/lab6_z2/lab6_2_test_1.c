#include <stdio.h>

int main() {
	int pass = 1;
	int i;
	int d[5];
	int expected[5] = {5, 6, 7, 8, 9};

	for (i = 0; i < 5; i++)	{
		d[i] = i + 5;
	}

	foo(d);

	for (i = 0; i < 5; i++)	{
		fprintf(stdout, "%d: Expeced %d Actual %d\n", i, expected[i], d[i]);	
		if(expected[i] != d[i]) {
			pass = 0;
		} 
	}	


	if (pass)
	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}
	else
	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
