#include "types_float_double.h"

void types_float_double(
  din_A  inA,
  din_B  inB,
  din_C  inC,
  din_D  inD,
  dout_1 *out1,
  dout_2 *out2,
  dout_3 *out3,
  dout_4 *out4
  ) {

	// Basic arithmetic and math.h sqrt()
	*out1 = inA * inB;
	*out2 = inB + inA;
	*out3 = inC / inA;
	*out4 = sqrtf(inD);

}


