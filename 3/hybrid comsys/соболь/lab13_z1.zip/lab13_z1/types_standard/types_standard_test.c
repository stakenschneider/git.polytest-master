#include "types_standard.h"
 
int main () {
  din_A  inA;
  din_B  inB;
  din_C  inC;
  din_D  inD;
  dout_1 out1;
  dout_2 out2;
  dout_3 out3;
  dout_4 out4;

	int i, retval=0;
	FILE        *fp;

	// Save the results to a file
	fp=fopen("result.dat","w");

	for (i=0;i<N;i++) {
		// Create input data
    inA = i+2;
    inB = i+23;
    inC = i+234;
    inD = i+2345;

        // Call the function to operate on the data
        types_standard(inA,inB,inC,inD,&out1,&out2,&out3,&out4);
#ifndef __MINGW32__
		fprintf(fp, "%d*%d=%d; %d+%d=%d; %d/%d=%d; %lld mod %d=%d;\n", inA, inB, out1, inB, inA, out2, inC, inA, out3, inD, inA,out4);
#else
		fprintf(fp, "%d*%d=%d; %d+%d=%d; %d/%d=%d; %I64d mod %d=%d;\n", inA, inB, out1, inB, inA, out2, inC, inA, out3, inD, inA,out4);
#endif
	}
	fclose(fp);

	// Compare the results file with the golden results
	retval = system("diff --brief -w result.dat result.golden.dat");
	if (retval != 0) {
		printf("Test failed  !!!\n"); 
		retval=1;
	} else {
		printf("Test passed !\n");
  }

	// Return 0 if the test passed
  return retval;
}

