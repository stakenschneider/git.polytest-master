#ifndef _APINT_ARITH_H_
#define _APINT_ARITH_H_

#include <stdio.h>
#include "ap_cint.h"

#define N 9

typedef int6 dinA_t;
typedef int12 dinB_t;
typedef int22 dinC_t;
typedef int33 dinD_t;

typedef int18 dout1_t;
typedef uint13 dout2_t;
typedef int22 dout3_t;
typedef int6 dout4_t;

void apint_arith(dinA_t inA,dinB_t inB,dinC_t inC,dinD_t inD,dout1_t *out1,dout2_t *out2,dout3_t *out3,dout4_t *out4);

#endif

