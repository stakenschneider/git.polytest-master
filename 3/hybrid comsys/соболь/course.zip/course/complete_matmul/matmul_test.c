#include <stdio.h>
#include "matmul.h"

void data(int seed, int A[N][M], int B[M][P], int AB[N][P]) {
    for(int i = 0; i < N; ++i) {
        for(int j = 0; j < P; ++j) {
            int ABij = 0;
            for(int k = 0; k < M; ++k) {
                A[i][k] = (i * N + k) * seed;
                B[k][j] = (k * M + j) * seed;
                ABij += A[i][k] * B[k][j];
            }
            AB[i][j] = ABij;
        }
    }   
}

int matrix_equal(int A[N][P], int B[N][P]){
    for(int i = 0; i < N; ++i) {
        for(int j = 0; j < P; ++j) {
            if(A[i][j] != B[i][j]){
                return 0;
            }
        }
    }
    return 1;
}

int main() {
    int A_in[N][M], B_in[M][P];
    int AB_actual[N][P], AB_expected[N][P];

    int pass = 1;

    for (int i = 1; i < 4; ++i){
        data(i, A_in, B_in, AB_expected);

        matmul(A_in, B_in, AB_actual);

        if(!matrix_equal(AB_actual, AB_expected)){
            pass = 0;
        }
    }

    if(pass){
        printf("Test passed\n");
        return 0;
    } else{
        printf("Test failed\n");
        return -1;
    }

}
