#define N 128
#define M 128
#define P 128
