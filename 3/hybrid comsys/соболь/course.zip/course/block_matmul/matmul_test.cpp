#include <stdio.h>
#include "matmul.h"

void data(int seed, int A[SIZE][SIZE], int B[SIZE][SIZE], int AB[SIZE][SIZE]) {
    for(int i = 0; i < SIZE; ++i) {
        for(int j = 0; j < SIZE; ++j) {
            int ABij = 0;
            for(int k = 0; k < SIZE; ++k) {
                A[i][k] = (i * SIZE + k) * seed;
                B[k][j] = (k * SIZE + j) * seed;
                ABij += A[i][k] * B[k][j];
            }
            AB[i][j] = ABij;
        }
    }   
}

int matrix_equal(int A[SIZE][SIZE], int B[SIZE][SIZE]){
    for(int i = 0; i < SIZE; ++i) {
        for(int j = 0; j < SIZE; ++j) {
            if(A[i][j] != B[i][j]){
                return 0;
            }
        }
    }
    return 1;
}

void block_matmul(int A[SIZE][SIZE], int B[SIZE][SIZE], int AB[SIZE][SIZE]){
    hls::stream<blockvec> A_matrix("A_matrix");
    hls::stream<blockvec> B_matrix("B_matrix");
    blockvec A_matrix_block, B_matrix_block;
    blockmat block_out;

    int it = 0;
    for(int row = 0; row < SIZE; row = row + BLOCK_SIZE) {
        for(int col = 0; col < SIZE; col = col + BLOCK_SIZE) {
            
            for(int k = 0; k < SIZE; k++) {
                for(int i = 0; i < BLOCK_SIZE; i++) {
                    if(it % (SIZE/BLOCK_SIZE) == 0) {
                        A_matrix_block.block[i] = A[row+i][k];
                    }
                    B_matrix_block.block[i] = B[k][col+i];
                }
                if(it % (SIZE/BLOCK_SIZE) == 0) {
                    A_matrix.write(A_matrix_block);
                }
                B_matrix.write(B_matrix_block);
            }

            matmul(A_matrix, B_matrix, block_out, it);
            
            for(int i = 0; i < BLOCK_SIZE; i++){
                for(int j = 0; j < BLOCK_SIZE; j++){
                    AB[row+i][col+j] = block_out.matrix[i][j];
                }
            }

            it = it + 1;
        }
    }
}

int main() {
    int A_in[SIZE][SIZE], B_in[SIZE][SIZE];
    int AB_actual[SIZE][SIZE], AB_expected[SIZE][SIZE];
    
    int pass = 1;

    for (int i = 1; i < 4; ++i){
        data(i, A_in, B_in, AB_expected);

        block_matmul(A_in, B_in, AB_actual);

        if(!matrix_equal(AB_actual, AB_expected)){
            pass = 0;
        }
    }

    if(pass){
        printf("Test passed\n");
        return 0;
    } else{
        printf("Test failed\n");
        return -1;
    }

}
