#pragma once

#include "hls_stream.h"
#include <iostream>
#include <iomanip>
#include <vector>

typedef int DTYPE;
const int BLOCK_SIZE = 4;
const int SIZE = 128;

typedef struct {
	DTYPE block[BLOCK_SIZE]; 
} blockvec;

typedef struct {
	DTYPE matrix[BLOCK_SIZE][BLOCK_SIZE]; 
} blockmat;

void matmul(hls::stream<blockvec> &Arows, hls::stream<blockvec> &Bcols, blockmat & ABpartial, int iteration);
