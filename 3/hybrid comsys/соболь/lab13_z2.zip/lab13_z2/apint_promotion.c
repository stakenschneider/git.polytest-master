#include "apint_promotion.h"

dout_t apint_promotion(din_t a,din_t b) {
  dout_t  tmp;
  #ifdef ENABLE_TYPE_CAST
	tmp = (dout_t)a * (dout_t)b;
  #else
  	tmp = a * b;
  #endif
  return tmp;
}

