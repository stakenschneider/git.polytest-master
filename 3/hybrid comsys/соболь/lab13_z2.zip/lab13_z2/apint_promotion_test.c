#include "apint_promotion.h"
 
int main () {
	din_t A, B;
	dout_t RES;
	int i, retval=0;
	FILE        *fp;

	// Save the results to a file
	fp=fopen("result.dat","w");

	// Call the function
	A=65536;
	B=65536;
	for(i=0; i<(20);++i) {
    RES=apint_promotion(A,B);
#ifndef __MINGW32__
        fprintf(fp, "%lld \n", RES);
#else
        fprintf(fp, "%I64d \n", RES);
#endif
		A=A+1024;
		B=B-2047;
	}
	fclose(fp);

	// Compare the results file with the golden results
	retval = system("diff --brief -w result.dat result.golden.dat");
	if (retval != 0) {
		printf("Test failed  !!!\n"); 
		retval=1;
	} else {
		printf("Test passed !\n");
  }

	// Return 0 if the test passes
  return retval;
}

