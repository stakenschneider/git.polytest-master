#ifndef _APINT_PROMOTION_H_
#define _APINT_PROMOTION_H_

#include <stdio.h>
#include "ap_cint.h"

typedef int18 din_t;
typedef int36 dout_t;

dout_t apint_promotion(din_t a,din_t b);

#endif

