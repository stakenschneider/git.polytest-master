int lab4_1( int a, int b, int *c, int *d, int *p_y) {
	int y;
	y = a*b + *c;
	*p_y = a*b + *d;
	return y;
}
