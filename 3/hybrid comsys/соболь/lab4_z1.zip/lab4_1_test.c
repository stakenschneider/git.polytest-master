#include <stdio.h>

int main()
{
	int inA, inB, inC, inD, inPY;
	int res;
	// For adders
	int refOut[3] = {230, 640, 1250};
	int refPY[3] = {240, 650, 1260};
	int pass;
	int i;

	inA = 10;
	inB = 20;
	inC = 30;
	inD = 40;
	inPY = 0;

	// Call the adder for 5 transactions
	for (i=0; i<3; i++)
	{
		res = lab4_1(inA, inB, &inC, &inD, &inPY);

		fprintf(stdout, "  %d*%d+%d=%d \n", inA, inB, inC, res);
		fprintf(stdout, "  %d*%d+%d=%d \n", inA, inB, inD, inPY);

	  // Test the output against expected results
		if (res == refOut[i] && inPY == refPY[i])
			pass = 1;
		else
			pass = 0;

		inA=inA+10;
		inB=inB+10;
		inC=inC+10;
		inD=inD+10;
	}

	if (pass)
	{
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	}
	else
	{
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
