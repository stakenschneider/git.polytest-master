#ifndef _LOOP_IMPERFECT_H_
#define _LOOP_IMPERFECT_H_

#include "ap_cint.h"
#define N 20

typedef int5 din_t;
typedef int12 dint_t;
typedef int6 dout_t;

void loop_imperfect(din_t A[N], dout_t B[N]);

#endif

