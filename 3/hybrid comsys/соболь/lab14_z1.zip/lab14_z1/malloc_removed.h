#ifndef _MALLOC_REMOVED_H_
#define _MALLOC_REMOVED_H_

#include <stdio.h>
#define N 32

typedef int din_t;
typedef long long dout_t;
typedef int dsel_t;

dout_t malloc_removed(din_t din[N], dsel_t width);

#endif

