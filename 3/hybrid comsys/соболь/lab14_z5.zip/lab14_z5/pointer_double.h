#ifndef _POINTER_DOUBLE_H_
#define _POINTER_DOUBLE_H_

#include <stdio.h>


typedef int data_t;

data_t pointer_double(data_t pos, data_t x, data_t* flag);

#endif

