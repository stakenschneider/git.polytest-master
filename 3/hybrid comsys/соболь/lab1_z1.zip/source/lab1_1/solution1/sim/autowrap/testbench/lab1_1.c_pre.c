# 1 "D:/10Semester/vivado/lab1_z1/source/lab1_1.c"
# 1 "D:/10Semester/vivado/lab1_z1/source/lab1_1.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "D:/10Semester/vivado/lab1_z1/source/lab1_1.c" 2
int lab1_1( char a, char b, char c, char d) {
int y;
y = a*b+c+d;
return y;
}
