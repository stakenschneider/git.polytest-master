#include "lab11_4.h"
#include <stdio.h>

int main()
{
	int a_actual[N],a_expected[N],b[N],c[N],d[N];

	int i,passed = 1;

	for(i = N  - 1; i >= 0 ; i--)
	{
		b[i] = N*(i * i % 3);
		c[i] = i;
		d[i] = i % 2;
		if(d[i])
		{
			a_expected[i] = b[i] + c[i];
		}
		if(!d[i])
		{
			a_expected[i] = b[i] - c[i];
		}
	}

	lab11_4(a_actual,b,c,d);

	for(i = N - 1; i >= 0; i--)
	{
		printf("Expected [%d] actual [%d]\n",a_expected[i],a_actual[i]);
		if(a_expected[i] != a_actual[i])
		{
			passed = -1;
		}
	}

	if(passed != 1)	{
		printf("----------Test failed----------\n");
	} else {
		printf("----------Test passed----------\n");
	}
}
