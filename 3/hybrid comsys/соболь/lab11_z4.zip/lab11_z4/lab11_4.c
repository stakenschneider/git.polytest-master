#include "lab11_4.h"

void lab11_4(int a[N],int b[N],int c[N],int d[N])
{

	int i;

	Add:for(i = N - 1; i >= 0;i--)
	{
		if(d[i])
		{
			a[i] = b[i] + c[i];
		}
	}

	Sub:for(i = N - 1; i >= 0; i--)
	{
		if(!d[i])
		{
			a[i] = b[i] - c[i];
		}
	}
}

