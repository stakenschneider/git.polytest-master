#include <stdio.h>
#include "lab8_2.h"

int main() {
	int data_in[N];
	int data_out[N];
	int data_out_expected[N];
	int scale = 2;
	int pass = 1;

	int i, j;

	for (i = 0; i < N; i++) {
		data_in[i] = 211*i % 9;
		int temp1 = data_in[i] * scale + 123;
		int temp2 = data_in[i] >> scale;
		data_out_expected[i] = temp1 + temp2;
	}

	foo(data_in,scale,data_out);

	for (i = 0; i < N; i++) {
		printf("Expected:[%d], \tActual:[%d]\n",data_out_expected[i],data_out[i] );
		if (data_out_expected[i] != data_out[i] ) {
			pass = 0;	
		
		}
	}
	if(pass){
		printf("-------Test Pass-------\n");	
		return 0;
	} else {
		printf("-------ERROR-------\n");
		return -1;
	}	
}
