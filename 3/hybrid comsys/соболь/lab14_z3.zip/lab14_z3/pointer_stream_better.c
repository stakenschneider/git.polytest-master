#include "pointer_stream_better.h"


#ifdef USE_VOLATILE

void pointer_stream_better ( volatile dout_t *d_o,  volatile din_t *d_i)

#else

void pointer_stream_better ( dout_t *d_o,  din_t *d_i)

#endif
{
    din_t acc = 0;

    acc += *d_i;
    acc += *d_i;
    *d_o = acc;
    acc += *d_i;
    acc += *d_i;
    *d_o = acc;
}

