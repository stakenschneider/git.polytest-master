#include "lab11_1.h"
void lab11_1(int a[N], int b[N], int c[N])
{
	int i;
	Add:for (i = 0; i < N; i++)
	{
		a[i] = b[i] + c[i];
	}
}
