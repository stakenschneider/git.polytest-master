void lab7_3 (int in1, int in2, int *out_data) {
	int i;
	static int acc = 0;

	L1: for(i = 0; i < 20; i++) {
		acc = acc + in1 + in2;
	}
	*out_data = acc;
}
