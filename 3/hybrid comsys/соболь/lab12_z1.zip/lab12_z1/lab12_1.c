void sumsub_func(int *in1,int *in2,int *outSum, int *outSub)
{
	*outSum = *in1 + *in2;
	*outSub = *in1 - *in2;
}
void shift_func(int *in1,int *in2,int *outA, int *outB)
{
	*outA = *in1 >> 1;
	*outB = *in2 >> 2;
}
void add_sub_pass(int A,int B,int *C, int *D)
{
	int apb, amb;
	int a2, b2;

	sumsub_func(&A,&B,&apb,&amb);
	sumsub_func(&apb,&amb,&a2,&b2);
	shift_func(&a2,&b2,C,D);
}
