#define N 16
int main()
{
	int A,B,C,D,C_Exp,D_Exp;
	int pass = 1;
	for(int i = 0;i < N; i++)
	{
		A = (i*123 - 16) / 7;
		B = (i*A - 11) / 3;
		C_Exp = ((A - B) + (A + B)) >> 1;
		D_Exp = ((A + B) - (A - B)) >> 2;
		add_sub_pass(A,B,&C,&D);
		printf("A = %d B = %d C = %d C_Exp = %d D = %d D_Exp = %d\n",A,B,C,C_Exp,D,D_Exp);
		if(C != C_Exp || D != D_Exp)
			pass = 0;
	}
	if(pass)
	{
		printf("-----------Test passed------------\n");
	} else {
		printf("-----------Test failed------------\n");
	}
	return 0;
}
