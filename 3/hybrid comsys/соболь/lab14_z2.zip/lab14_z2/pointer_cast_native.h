#ifndef _POINTER_CAST_NATIVE_H_
#define _POINTER_CAST_NATIVE_H_

#include <stdio.h>

#define N 1024

typedef int data_t;
typedef char dint_t;

data_t pointer_cast_native (data_t index,  data_t A[N]);

#endif

