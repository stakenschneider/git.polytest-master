#include "struct_port.h"

data_t struct_port(
  data_t  i_val,
  data_t  *i_pt,
  data_t  *o_pt
  ) {

  data_t  o_val;
  int i;

	// Transfer pass-by-value structs
  o_val.A = i_val.A+2;
  for (i=0;i<4;i++) {
    o_val.B[i] = i_val.B[i]+2;
  }

	// Transfer pointer structs
  o_pt->A = i_pt->A+3;
  for (i=0;i<4;i++) {
    o_pt->B[i] = i_pt->B[i]+3;
  }

	return o_val;
}


