#ifndef _STRUCT_PORT_H_
#define _STRUCT_PORT_H_

#include <stdio.h>

typedef struct {
  unsigned short A;
  unsigned char B[4];
  }	data_t;

data_t struct_port(data_t i_val, data_t *i_pt, data_t *o_pt);

#endif

