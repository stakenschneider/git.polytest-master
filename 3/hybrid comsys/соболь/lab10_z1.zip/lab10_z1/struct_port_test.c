#include "struct_port.h"
 
int main () {
  data_t d_ival, d_ipt;
  data_t d_oval, d_opt;

	int i, retval=0;
	FILE        *fp;

	// Create input data
  d_ival.A = 19;
  d_ipt.A = 29;
	for (i=0;i<4;i++) {
    d_ival.B[i] = i+10;
    d_ipt.B[i] = i+20;
  }

	// Call the function to operate on the data
	d_oval = struct_port(d_ival, &d_ipt, &d_opt);

	// Save the results to a file
	fp=fopen("result.dat","w");
	fprintf(fp, "Din Dout\n");

  fprintf(fp, "%d   %d\n", d_oval.A, d_opt.A);
	for (i=0;i<4;i++) {
    fprintf(fp, "%d   %d\n", d_oval.B[i], d_opt.B[i]);
	}
	fclose(fp);

	// Compare the results file with the golden results
	retval = system("diff --brief -w result.dat result.golden.dat");
	if (retval != 0) {
		printf("Test failed  !!!\n"); 
		retval=1;
	} else {
		printf("Test passed !\n");
  }

	// Return 0 if the test passed
  return retval;
}

